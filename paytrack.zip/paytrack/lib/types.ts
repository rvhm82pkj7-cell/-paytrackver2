export type Shift = {
  id: string;
  date: string;
  start: string;
  end: string;
  breakMinutes: number;
  transport: number;
  memo: string;
};

export type Goal = {
  id: string;
  name: string;
  target: number;
  current: number;
  priority: boolean;
};

export type Settings = {
  hourlyWage: number;
  closingDay: number;
  payday: number;
  nightRate: number;
  dependentLimit: number;
};

export type Notice = {
  id: string;
  title: string;
  body: string;
  date: string;
  read: boolean;
};

export type AppState = {
  shifts: Shift[];
  goals: Goal[];
  settings: Settings;
  notices: Notice[];
};
