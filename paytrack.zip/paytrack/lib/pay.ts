import type { Settings, Shift } from "./types";

const toMinutes = (value: string) => {
  const [hour, minute] = value.split(":").map(Number);
  return hour * 60 + minute;
};

const overlap = (start: number, end: number, rangeStart: number, rangeEnd: number) =>
  Math.max(0, Math.min(end, rangeEnd) - Math.max(start, rangeStart));

export function calculateShiftPay(shift: Shift, settings: Settings) {
  let start = toMinutes(shift.start);
  let end = toMinutes(shift.end);
  if (end <= start) end += 1440;

  const duration = Math.max(0, end - start);
  const paidMinutes = Math.max(0, duration - Math.max(0, shift.breakMinutes));
  let nightMinutes = overlap(start, end, 1320, 1440) + overlap(start, end, 1440, 1740) + overlap(start, end, 0, 300);
  nightMinutes = Math.min(nightMinutes, paidMinutes);
  const normalMinutes = Math.max(0, paidMinutes - nightMinutes);

  const total =
    (normalMinutes / 60) * settings.hourlyWage +
    (nightMinutes / 60) * settings.hourlyWage * settings.nightRate +
    shift.transport;

  return { total: Math.round(total), normalMinutes, nightMinutes };
}

export const yen = (value: number) => `¥${Math.round(value).toLocaleString("ja-JP")}`;

export function payrollKey(dateString: string, settings: Settings) {
  const date = new Date(`${dateString}T00:00:00`);
  let year = date.getFullYear();
  let month = date.getMonth();
  if (date.getDate() > settings.closingDay) {
    month += 1;
    if (month > 11) { month = 0; year += 1; }
  }
  return `${year}-${String(month + 1).padStart(2, "0")}`;
}
