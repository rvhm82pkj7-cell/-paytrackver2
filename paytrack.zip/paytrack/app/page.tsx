"use client";

import { useEffect, useMemo, useState } from "react";
import { Bell, CalendarDays, ChevronLeft, ChevronRight, CircleDollarSign, Home, Plus, Settings as SettingsIcon, Target, Trash2, X } from "lucide-react";
import { calculateShiftPay, payrollKey, yen } from "@/lib/pay";
import type { AppState, Goal, Settings, Shift } from "@/lib/types";

const STORAGE_KEY = "paytrack-v1";
const uid = () => crypto.randomUUID();
const todayString = () => new Date().toISOString().slice(0, 10);

const initialState: AppState = {
  settings: { hourlyWage: 1200, closingDay: 15, payday: 25, nightRate: 1.25, dependentLimit: 1_030_000 },
  shifts: [],
  goals: [],
  notices: [
    { id: "welcome", title: "PayTrackへようこそ", body: "最初に設定画面で時給・締め日・給料日を確認してください。", date: todayString(), read: false },
  ],
};

type Tab = "home" | "shifts" | "goals" | "settings";
type Modal = "shift" | "goal" | "notices" | "contact" | null;

export default function Page() {
  const [state, setState] = useState<AppState>(initialState);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<Tab>("home");
  const [modal, setModal] = useState<Modal>(null);
  const [selectedDate, setSelectedDate] = useState(todayString());
  const [calendarMonth, setCalendarMonth] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const [editingShift, setEditingShift] = useState<Shift | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { setState(JSON.parse(saved)); } catch { /* keep defaults */ }
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state, ready]);

  const year = new Date().getFullYear();
  const yearIncome = useMemo(() => state.shifts.filter(s => s.date.startsWith(String(year))).reduce((sum, shift) => sum + calculateShiftPay(shift, state.settings).total, 0), [state, year]);
  const nextKey = useMemo(() => payrollKey(todayString(), state.settings), [state.settings]);
  const nextSalaryShifts = useMemo(() => state.shifts.filter(s => payrollKey(s.date, state.settings) === nextKey), [state, nextKey]);
  const nextSalary = nextSalaryShifts.reduce((sum, shift) => sum + calculateShiftPay(shift, state.settings).total, 0);
  const priorityGoal = state.goals.find(goal => goal.priority);
  const upcoming = [...state.shifts].filter(s => s.date >= todayString()).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 3);
  const unread = state.notices.filter(n => !n.read).length;

  const openShift = (date = selectedDate, shift?: Shift) => {
    setSelectedDate(date);
    setEditingShift(shift ?? null);
    setModal("shift");
  };

  const saveShift = (shift: Shift) => {
    setState(current => ({ ...current, shifts: current.shifts.some(s => s.id === shift.id) ? current.shifts.map(s => s.id === shift.id ? shift : s) : [...current.shifts, shift] }));
    setSelectedDate(shift.date);
    setModal(null);
  };

  const deleteShift = (id: string) => {
    setState(current => ({ ...current, shifts: current.shifts.filter(s => s.id !== id) }));
    setModal(null);
  };

  const addGoal = (goal: Goal) => {
    setState(current => ({ ...current, goals: [...current.goals.map(g => goal.priority ? { ...g, priority: false } : g), goal] }));
    setModal(null);
  };

  const markNoticesRead = () => {
    setState(current => ({ ...current, notices: current.notices.map(n => ({ ...n, read: true })) }));
    setModal("notices");
  };

  if (!ready) return <main className="loading">PayTrackを読み込み中…</main>;

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand">Pay<span>Track</span></div>
        <div className="top-actions">
          <button className="icon-button" aria-label="お知らせ" onClick={markNoticesRead}><Bell size={20}/>{unread > 0 && <span className="badge">{unread}</span>}</button>
          <button className="icon-button" aria-label="設定" onClick={() => setTab("settings")}><SettingsIcon size={20}/></button>
        </div>
      </header>

      <section className="content">
        {tab === "home" && <HomeTab year={year} yearIncome={yearIncome} salary={nextSalary} settings={state.settings} income={yearIncome} priorityGoal={priorityGoal} upcoming={upcoming} />}
        {tab === "shifts" && <ShiftTab month={calendarMonth} setMonth={setCalendarMonth} selectedDate={selectedDate} setSelectedDate={setSelectedDate} shifts={state.shifts} settings={state.settings} onAdd={openShift} onEdit={shift => openShift(shift.date, shift)} />}
        {tab === "goals" && <GoalTab goals={state.goals} settings={state.settings} onAdd={() => setModal("goal")} onDelete={id => setState(current => ({ ...current, goals: current.goals.filter(g => g.id !== id) }))} />}
        {tab === "settings" && <SettingsTab settings={state.settings} onChange={settings => setState(current => ({ ...current, settings }))} onNotices={markNoticesRead} onContact={() => setModal("contact")} />}
      </section>

      {tab !== "settings" && <button className="fab" aria-label="シフト追加" onClick={() => openShift()}><Plus/></button>}
      <BottomNav tab={tab} setTab={setTab}/>

      {modal === "shift" && <ShiftModal shift={editingShift} date={selectedDate} settings={state.settings} onClose={() => setModal(null)} onSave={saveShift} onDelete={deleteShift}/>} 
      {modal === "goal" && <GoalModal onClose={() => setModal(null)} onSave={addGoal}/>} 
      {modal === "notices" && <SimpleModal title="お知らせ" onClose={() => setModal(null)}>{state.notices.map(n => <article className="notice" key={n.id}><strong>{n.title}</strong><p>{n.body}</p><small>{n.date}</small></article>)}</SimpleModal>}
      {modal === "contact" && <ContactModal onClose={() => setModal(null)}/>} 
    </main>
  );
}

function HomeTab({ year, yearIncome, salary, settings, income, priorityGoal, upcoming }: { year:number; yearIncome:number; salary:number; settings:Settings; income:number; priorityGoal?:Goal; upcoming:Shift[] }) {
  const remain = Math.max(0, settings.dependentLimit - income);
  return <>
    <div className="hero"><span>{year}年の収入</span><strong>{yen(yearIncome)}</strong><small>保存したシフトから自動集計</small></div>
    <Card title="次の支給見込み額"><div className="big-number">{yen(salary)}</div><p className="muted">締め日：{settings.closingDay}日 ／ 給料日：{settings.payday}日<br/>※控除前の支給見込み額</p></Card>
    <Card title="扶養"><div className="medium-number">あと {yen(remain)}</div><Progress value={income / settings.dependentLimit * 100}/><p className="muted">上限 {yen(settings.dependentLimit)} ・ あと約{Math.ceil(remain / settings.hourlyWage)}時間</p></Card>
    <Card title="優先目標">{priorityGoal ? <GoalSummary goal={priorityGoal} hourlyWage={settings.hourlyWage}/> : <Empty text="優先目標がありません"/>}</Card>
    <Card title="次のシフト">{upcoming.length ? upcoming.map(s => <ShiftRow key={s.id} shift={s} settings={settings}/>) : <Empty text="今後のシフトはありません"/>}</Card>
  </>;
}

function ShiftTab({ month, setMonth, selectedDate, setSelectedDate, shifts, settings, onAdd, onEdit }: any) {
  const year=month.getFullYear(), m=month.getMonth(), first=new Date(year,m,1).getDay(), last=new Date(year,m+1,0).getDate();
  const selected=shifts.filter((s:Shift)=>s.date===selectedDate);
  return <><h1>シフト</h1><Card>
    <div className="calendar-title"><button className="icon-button" onClick={()=>setMonth(new Date(year,m-1,1))}><ChevronLeft/></button><strong>{year}年{m+1}月</strong><button className="icon-button" onClick={()=>setMonth(new Date(year,m+1,1))}><ChevronRight/></button></div>
    <div className="calendar-grid">{["日","月","火","水","木","金","土"].map(d=><small key={d}>{d}</small>)}{Array.from({length:first}).map((_,i)=><span key={'e'+i}/>)}{Array.from({length:last},(_,i)=>i+1).map(day=>{const date=`${year}-${String(m+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`; const has=shifts.some((s:Shift)=>s.date===date);return <button key={day} className={`day ${has?'has-shift':''} ${selectedDate===date?'selected':''}`} onClick={()=>setSelectedDate(date)}>{day}</button>})}</div>
  </Card><Card title={selectedDate}>{selected.length ? selected.map((s:Shift)=><div className="editable-row" key={s.id}><ShiftRow shift={s} settings={settings}/><button className="small-button" onClick={()=>onEdit(s)}>編集</button></div>) : <><Empty text="シフトはありません"/><button className="primary" onClick={()=>onAdd(selectedDate)}>この日に追加</button></>}</Card></>;
}

function GoalTab({ goals, settings, onAdd, onDelete }: any) { return <><h1>目標</h1>{goals.length ? goals.map((g:Goal)=><Card key={g.id}>{g.priority&&<span className="priority">★ 優先目標</span>}<GoalSummary goal={g} hourlyWage={settings.hourlyWage}/><button className="danger-button" onClick={()=>onDelete(g.id)}><Trash2 size={16}/>削除</button></Card>) : <Card><Empty text="目標がありません"/></Card>}<button className="primary" onClick={onAdd}>＋ 新しい目標を追加</button></> }

function SettingsTab({ settings, onChange, onNotices, onContact }: any) {
  const update=(key:keyof Settings,value:number)=>onChange({...settings,[key]:value});
  return <><h1>設定</h1><Card>{[
    ["時給","hourlyWage",settings.hourlyWage],["締め日","closingDay",settings.closingDay],["給料日","payday",settings.payday],["深夜倍率","nightRate",settings.nightRate],["扶養上限","dependentLimit",settings.dependentLimit]
  ].map(([label,key,value])=><label className="setting-field" key={String(key)}><span>{label}</span><input type="number" value={Number(value)} step={key==='nightRate'?0.05:1} onChange={e=>update(key as keyof Settings,Number(e.target.value))}/></label>)}</Card><Card><button className="menu-row" onClick={onNotices}>🔔 お知らせ <span>›</span></button><button className="menu-row" onClick={onContact}>📩 お問い合わせ <span>›</span></button></Card></>;
}

function ShiftModal({ shift, date, settings, onClose, onSave, onDelete }: any) {
  const [form,setForm]=useState<Shift>(shift ?? {id:uid(),date,start:"18:00",end:"23:30",breakMinutes:60,transport:0,memo:""});
  const calc=calculateShiftPay(form,settings); const set=(key:keyof Shift,value:any)=>setForm(v=>({...v,[key]:value}));
  return <SimpleModal title={shift?"シフトを編集":"シフトを追加"} onClose={onClose}><div className="two-cols"><Field label="開始時間"><input type="time" value={form.start} onChange={e=>set("start",e.target.value)}/></Field><Field label="終了時間"><input type="time" value={form.end} onChange={e=>set("end",e.target.value)}/></Field></div><Field label="休憩（分）"><input type="number" min="0" value={form.breakMinutes} onChange={e=>set("breakMinutes",Number(e.target.value))}/></Field><Field label="勤務日"><input type="date" value={form.date} onChange={e=>set("date",e.target.value)}/></Field><Field label="交通費（任意）"><input type="number" min="0" value={form.transport} onChange={e=>set("transport",Number(e.target.value))}/></Field><Field label="メモ（任意）"><textarea value={form.memo} onChange={e=>set("memo",e.target.value)}/></Field><div className="preview"><span>支給見込み額</span><strong>{yen(calc.total)}</strong></div><button className="primary" onClick={()=>onSave(form)}>保存</button>{shift&&<button className="danger-button full" onClick={()=>onDelete(form.id)}><Trash2 size={17}/>削除</button>}</SimpleModal>;
}

function GoalModal({ onClose, onSave }: any) { const [name,setName]=useState(""); const [target,setTarget]=useState(0); const [current,setCurrent]=useState(0); const [priority,setPriority]=useState(false); return <SimpleModal title="新しい目標" onClose={onClose}><Field label="目標名"><input value={name} onChange={e=>setName(e.target.value)}/></Field><Field label="目標金額"><input type="number" value={target||""} onChange={e=>setTarget(Number(e.target.value))}/></Field><Field label="現在の金額（任意）"><input type="number" value={current||""} onChange={e=>setCurrent(Number(e.target.value))}/></Field><label className="checkbox"><input type="checkbox" checked={priority} onChange={e=>setPriority(e.target.checked)}/>優先目標にする</label><button className="primary" disabled={!name||target<=0} onClick={()=>onSave({id:uid(),name,target,current,priority})}>保存</button></SimpleModal> }

function ContactModal({ onClose }: any) { const [sent,setSent]=useState(false); return <SimpleModal title="お問い合わせ" onClose={onClose}>{sent?<Empty text="お問い合わせを受け付けました（デモ）"/>:<form onSubmit={e=>{e.preventDefault();setSent(true)}}><Field label="返信先メール"><input type="email" required/></Field><Field label="内容"><textarea required rows={5}/></Field><button className="primary">送信する</button></form>}</SimpleModal> }
function SimpleModal({ title, onClose, children }: any) { return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><div className="sheet"><div className="sheet-head"><h2>{title}</h2><button className="icon-button" onClick={onClose}><X/></button></div>{children}</div></div> }
function Card({ title, children }: any) { return <section className="card">{title&&<h2>{title}</h2>}{children}</section> }
function Field({ label, children }: any) { return <label className="field"><span>{label}</span>{children}</label> }
function Empty({ text }: {text:string}) { return <div className="empty">{text}</div> }
function Progress({ value }: {value:number}) { return <div className="progress"><span style={{width:`${Math.max(0,Math.min(100,value))}%`}}/></div> }
function GoalSummary({ goal, hourlyWage }: {goal:Goal;hourlyWage:number}) { const pct=Math.min(100,goal.current/goal.target*100),remain=Math.max(0,goal.target-goal.current); return <><div className="goal-head"><strong>{goal.name}</strong><b>{Math.round(pct)}%</b></div><p className="muted">{yen(goal.current)} / {yen(goal.target)}</p><Progress value={pct}/><p className="muted">あと {yen(remain)} ・ 約{Math.ceil(remain/hourlyWage)}時間</p></> }
function ShiftRow({ shift, settings }: {shift:Shift;settings:Settings}) { const d=new Date(`${shift.date}T00:00:00`),days=["日","月","火","水","木","金","土"]; return <div className="shift-row"><div className="date-box"><small>{days[d.getDay()]}</small><strong>{d.getDate()}</strong><small>{d.getMonth()+1}月</small></div><div><strong>{shift.start}〜{shift.end}</strong><p>休憩{shift.breakMinutes}分</p></div><b>{yen(calculateShiftPay(shift,settings).total)}</b></div> }
function BottomNav({ tab, setTab }: {tab:Tab;setTab:(tab:Tab)=>void}) { const items:[Tab,any,string][]=[["home",Home,"ホーム"],["shifts",CalendarDays,"シフト"],["goals",Target,"目標"],["settings",SettingsIcon,"設定"]]; return <nav className="bottom-nav">{items.map(([id,Icon,label])=><button key={id} className={tab===id?"active":""} onClick={()=>setTab(id)}><Icon size={22}/><span>{label}</span></button>)}</nav> }
